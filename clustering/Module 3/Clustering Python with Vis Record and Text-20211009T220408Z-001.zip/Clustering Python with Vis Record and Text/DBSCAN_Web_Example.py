# -*- coding: utf-8 -*-
"""
Created on Sun Sep 25 11:15:54 2016

@author: Ami
"""

#DPSCANExample.py
# Reference: http://scikit-learn.org/stable/auto_examples/cluster/plot_cluster_comparison.html
# Ami Gates

import time
import numpy as np
import matplotlib.pyplot as plt
from sklearn import cluster, datasets
from sklearn.preprocessing import StandardScaler

n_samples = 500
noisy_circles = datasets.make_circles(n_samples=n_samples, factor=.5, noise=.05)
noisy_moons = datasets.make_moons(n_samples=n_samples, noise=.05)
blobs = datasets.make_blobs(n_samples=n_samples, random_state=8)
#Reference
#http://scikit-learn.org/stable/modules/generated/sklearn.datasets.make_blobs.html
#no_structure = np.random.rand(n_samples, 2)

colors = np.array([x for x in 'bgrcmykbgrcmykbgrcmykbgrcmyk'])
colors = np.hstack([colors] * 20)

clustering_names = ['KMeans','DBSCAN']

plt.figure(figsize=(len(clustering_names) * 2 + 3, 10))
plt.subplots_adjust(left=.02, right=.98, bottom=.001, top=.96, wspace=.25,hspace=.25)

plot_num = 1
datasets = [noisy_circles, noisy_moons, blobs]
for i_dataset, dataset in enumerate(datasets):
    X, y = dataset
    print("Std and mean of original data :", round(np.std(X),2), "and ", round(np.mean(X),2))
    # normalize dataset for easier parameter selection
    #Reference
    #http://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html
    X = StandardScaler().fit_transform(X)
    print("Std and mean of whitened data :", round(np.std(X),2), "and ", round(np.mean(X),2))
    
    #eps is: The maximum distance between 
    #two samples for them to be considered as in the same neighborhood.
    dbscan = cluster.DBSCAN(eps=.2)
    KMeans=cluster.KMeans(n_clusters=3)
    clustering_algorithms = [KMeans, dbscan]
        
    for name, algorithm in zip(clustering_names, clustering_algorithms):
        
        t0 = time.time()
        #run each cluster algorithm
        algorithm.fit(X)
        t1 = time.time()
        if hasattr(algorithm, 'labels_'):
            #cast labels to int
            y_pred = algorithm.labels_.astype(np.int)
        else:
            y_pred = algorithm.predict(X)

        # plot
        #reference
        #http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.subplot
        plt.subplot(4, len(clustering_algorithms), plot_num)
        if i_dataset == 0:
            plt.title(name, size=18)
            
        plt.scatter(X[:, 0], X[:, 1], color=colors[y_pred].tolist(), s=10)
        
        #https://docs.python.org/3/library/functions.html#hasattr
        if hasattr(algorithm, 'cluster_centers_'):
            centers = algorithm.cluster_centers_
            center_colors = colors[:len(centers)]
            plt.scatter(centers[:, 0], centers[:, 1], s=100, c=center_colors)
            
        plt.xlim(-2, 2)
        plt.ylim(-2, 2)
        plt.xticks(())
        plt.yticks(())
        plt.text(.99, .01, ('%.2fs' % (t1 - t0)).lstrip('0'),
                 transform=plt.gca().transAxes, size=15,
                 horizontalalignment='right')
        plot_num += 1

plt.show()