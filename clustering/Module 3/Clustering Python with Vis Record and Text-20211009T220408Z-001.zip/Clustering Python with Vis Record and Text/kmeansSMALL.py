

#kmeansSMALL.py

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.cluster import KMeans
from sklearn import datasets

iris = datasets.load_iris()
print(iris.data)


X = iris.data[:,:3]  ## ALl rows and first 3 columns
print(X)

y = iris.target
print(iris.target)


My_kmeans = KMeans(n_clusters=3, random_state=0)

Result=My_kmeans.fit(X)

print(My_kmeans)
print(My_kmeans.cluster_centers_)
#labels_: Labels of each point, attribute of Kmeans
labels = Result.labels_
print(labels)


###### Compare iris data with kmeans prediction in 3D #########
#plt.subplots(1, 2, figsize=(16,8))
fignum = 0
fig1 = plt.figure(fignum, figsize=(12, 12))
#plt.clf()  This clears the figure

#Axes3D is part of Matplot lib
# rect defines the rectangle
#elev stores the elevation angle in the z plane 
#azim stores the azimuth angle in the x,y plane
ax1 = Axes3D(fig1, rect=[0, 0, .90, 1], elev=48, azim=134)
# plt.cla()   This clears the axis
# c can be single color format string or a sequence of color specs of len N
# The labels are an array. labels.astype(np.float) casts to float

ax1.scatter(X[:, 0], X[:, 1], X[:, 2], c=y, cmap=plt.cm.Set1, edgecolor='k')
ax1.w_xaxis.set_ticklabels([])
ax1.w_yaxis.set_ticklabels([])
ax1.w_zaxis.set_ticklabels([])

ax1.set_xlabel('Sepal length')
ax1.set_ylabel('Sepal width')
ax1.set_zlabel('Petal length')
## The last (4th) is Petal width
plt.show()


fignum = 2
fig2 = plt.figure(fignum, figsize=(18, 18))
ax2 = Axes3D(fig2, rect=[0, 0, .90, 1], elev=48, azim=134)
# plt.cla()   This clears the axis
# c can be single color format string or a sequence of color specs of len N
# The labels are an array. labels.astype(np.float) casts to float

## Notice that c = labels
## This will give the kmeans results
ax2.scatter(X[:, 0], X[:, 1], X[:, 2], c=labels, cmap=plt.cm.Set1, edgecolor='k')
ax2.w_xaxis.set_ticklabels([])
ax2.w_yaxis.set_ticklabels([])
ax2.w_zaxis.set_ticklabels([])

ax2.set_xlabel('Sepal length')
ax2.set_ylabel('Sepal width')
ax2.set_zlabel('Petal length')
## The last (4th) is Petal width

plt.show()


##############----------------------------
fignum = 1
fig = plt.figure(fignum, figsize=(10, 10))
#plt.clf()  This clears the figure

#Axes3D is part of Matplot lib
# rect defines the rectangle
#elev stores the elevation angle in the z plane 
#azim stores the azimuth angle in the x,y plane
ax = Axes3D(fig, rect=[0, 0, .90, 1], elev=48, azim=134)
# plt.cla()   This clears the axis
# c can be single color format string or a sequence of color specs of len N
# The labels are an array. labels.astype(np.float) casts to float

ax.scatter(X[:, 0], X[:, 1], X[:, 2], c=labels, cmap=plt.cm.Set1, edgecolor='k')
ax.w_xaxis.set_ticklabels([])
ax.w_yaxis.set_ticklabels([])
ax.w_zaxis.set_ticklabels([])

ax.set_xlabel('Sepal length')
ax.set_ylabel('Sepal width')
ax.set_zlabel('Petal length')
## The last (4th) is Petal width

plt.show()


############### 2D reflection
ax.scatter(X[:, 0], X[:, 1], c=labels, cmap=plt.cm.Set1, edgecolor='k')

ax.w_xaxis.set_ticklabels([])
ax.w_yaxis.set_ticklabels([])

ax.set_xlabel('Sepal length')
ax.set_ylabel('Sepal width')

plt.show()