# -*- coding: utf-8 -*-
"""
Created on Thu Oct 19 13:29:20 2017

@author: Ami
"""
#CountVectorizer_sklearn.py
#Gates
#RE: https://de.dariah.eu/tatom/working_with_text.html
#and
#http://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.CountVectorizer.html
## http://scikit-learn.org/stable/modules/feature_extraction.html#the-bag-of-words-#representation
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt
from sklearn.manifold import MDS
from mpl_toolkits.mplot3d import Axes3D
from scipy.cluster.hierarchy import ward, dendrogram

import re

#from sklearn.feature_extraction.text import TfidfTransformer
#import re

##To get the DATA
#Go HERE
#https://de.dariah.eu/tatom/datasets.html#datasets
# Download and save the data used into the files/folders used.

# See: http://scikit-learn.org/stable/modules/feature_extraction.html#the-bag-of-words-#representation
# For code on IDF and TF_IDF

#vectorizer = CountVectorizer(min_df=1, ngram_range=(1,2), token_pattern=r'\b\w+\b')
#\b means match at exactly the start. r'\bclass\b' matches exactly " class "
#\w+ is one or more chars
# RE: https://docs.python.org/3/howto/regex.html
#corpus = ['This is the first document.',
 #         'This is the second document.',
  #        'And the third one.',
   #       'Is this the first document?']
          
List_Of_Files = ['../DATA/Novels_Corpus/Austen_Emma.txt', '../DATA/Novels_Corpus/Austen_Pride.txt', 
             '../DATA/Novels_Corpus/Austen_Sense.txt', '../DATA/Novels_Corpus/CBronte_Jane.txt',
             '../DATA/Novels_Corpus/CBronte_Professor.txt', '../DATA/Novels_Corpus/Dickens_Bleak.txt',
             '../DATA/Novels_Corpus/Dickens_David.txt', '../DATA/Novels_Corpus/Dickens_Hard.txt']

#FILE=open(filenames[0], "r")
#EmmaText=FILE.read()
#FILE.close()
#print(EmmaText[0:100])

vectorizer = CountVectorizer(input='filename', stop_words="english")
#Using input='filename' means that fit_transform will
#expect a list of file names
#dtm is document term matrix
dtm = vectorizer.fit_transform(List_Of_Files)  # create a sparse matrix
print(type(dtm))
#vocab is a vocabulary list
vocab = vectorizer.get_feature_names()  # change to a list
## !!!------------
dtm = dtm.toarray()  # convert to a regular array
## !!! To create the dataframe - you must first convert the dtm to an array
############# Change to Dataframe #############
CV_DF=pd.DataFrame(dtm,columns=vocab)
print(CV_DF.head())

## NOTICE that there are numbers as columns..........this is NOT good
## Now we must clean these out....
for nextcol in CV_DF.columns:
    if(re.search(r'[^A-Za-z]+', nextcol)):  ## find non chars
        #print(nextcol)  ## see what you are doing....
        CV_DF=CV_DF.drop([nextcol], axis=1)
#    ## The following will remove any column with name
#    ## of 3 or smaller - like "it" or "of" or "pre".
#    ##print(len(nextcol))  ## check it first
#    ## NOTE: You can also use this code to CONTROL
#    ## the words in the columns. For example - you can
#    ## have only words between lengths 5 and 9. 
        
#    ## In this case, we remove columns with words <= 3.
    elif(len(str(nextcol))<=3):
        #print(nextcol)
        CV_DF=CV_DF.drop([nextcol], axis=1)
        
## CHECK IT!
print(CV_DF.head())
        
##################
## Repeat the above for the Tfidf................
#############################################
vectorizer_tfidf = TfidfVectorizer(input='filename', stop_words="english")
dtmTF = vectorizer_tfidf.fit_transform(List_Of_Files)  # create a sparse matrix
#vocab is a vocabulary list
vocabTF = vectorizer_tfidf.get_feature_names()  # change to a list
## !!!------------
dtmTF = dtmTF.toarray()  # convert to a regular array
## !!! To create the dataframe - you must first convert the dtm to an array
############# Change to Dataframe #############
CV_TF=pd.DataFrame(dtmTF,columns=vocabTF)
print(CV_TF.head())

for nextcol in CV_TF.columns:
    if(re.search(r'[^A-Za-z]+', nextcol)):  ## find non chars
        #print(nextcol)  ## see what you are doing....
        CV_TF=CV_TF.drop([nextcol], axis=1)
#    ## The following will remove any column with name
#    ## of 3 or smaller - like "it" or "of" or "pre".
#    ##print(len(nextcol))  ## check it first
#    ## NOTE: You can also use this code to CONTROL
#    ## the words in the columns. For example - you can
#    ## have only words between lengths 5 and 9. 
        
#    ## In this case, we remove columns with words <= 3.
    elif(len(str(nextcol))<=3):
        #print(nextcol)
        CV_TF=CV_TF.drop([nextcol], axis=1)
        
## CHECK IT!
print(CV_TF.head())


############################
## Other things you can do....
#############################################
print(list(vocab)[500:550])
##Ways to count the word "house" in Emma (file 0 in the list of files)
house_idx = list(vocab).index('house') #index of "house" 
print(house_idx)
print(dtm[0, house_idx]) 
#Counting "house" in Pride
print(dtm[1,house_idx]) 
print(list(vocab)[house_idx]) #his prints "house"
print(dtm[500:550,500:550]) #prints the doc term matrix
#----------
##Create a table of word counts to compare Emma and Pride and Prejudice
columns=["BookName", "house","zornes"]
MyList=["Emma"]
MyList2=["Pride"]
MyList3=["Sense"]
for someword in ["house", "zornes"]:
    EmmaWord = (dtm[0, list(vocab).index(someword)])
    MyList.append(EmmaWord)
    PrideWord = (dtm[1, list(vocab).index(someword)])
    MyList2.append(PrideWord)
    SenseWord = (dtm[2, list(vocab).index(someword)])
    MyList3.append(SenseWord)


#print(MyList)
#print(MyList2)

df2=pd.DataFrame([columns, MyList,MyList2, MyList3])   
print(df2)

#############################################
##Comparing  - clustering - books
##################################################
#Each row of the document-term 
#matrix (dtm) is a sequence of a novel’s word frequencies
## Get the euclidean dist between Emma and Pride&Prejudice
#Using sklearn

################ -> You can also change the dtm to dtmTF to do the
##################  same thing for the tf-idf normalized data.

dist = euclidean_distances(dtm)
print(np.round(dist,0))  #The dist between Emma and Pride is 3856

#Measure of distance that takes into account the
#length of the document: called cosine similarity
cosdist = 1 - cosine_similarity(dtm)
print(np.round(cosdist,3))  #cos dist should be .02

## Visualizing Distances
##An option for visualizing distances is to assign a point in a plane
## to each text such that the distance between points is proportional 
## to the pairwise euclidean or cosine distances.
## This type of visualization is called multidimensional scaling (MDS) 
## in scikit-learn (and R  -  mdscale).

mds = MDS(n_components=2, dissimilarity="precomputed", random_state=1)
## "precomputed" means we will give the dist (as cosine sim)
pos = mds.fit_transform(cosdist)  # shape (n_components, n_samples)
xs, ys = pos[:, 0], pos[:, 1]
print(xs)
names=["Austen_Emma", "Austen_Pride", "Austen_Sense", "CBronte_Jane", 
       "CBronte_Professor", "Dickens_Bleak",
       "Dickens_David", "Dickens_Hard"]

for x, y, name in zip(xs, ys, names):
    plt.scatter(x, y)
    plt.text(x, y, name)

plt.show()

##PLotting the relative distances in 3D
mds = MDS(n_components=3, dissimilarity="precomputed", random_state=1)
pos = mds.fit_transform(cosdist)
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(pos[:, 0], pos[:, 1], pos[:, 2])
#print(pos[:,2])
for x, y, z, s in zip(pos[:, 0], pos[:, 1], pos[:, 2], names):
    ax.text(x, y, z, s)

ax.set_xlim3d(-.2,.3) #stretch out the x axis
ax.set_ylim3d(-.2,.3) #stretch out the x axis
ax.set_zlim3d(-.2,.2) #stretch out the z axis
plt.show()

## Clustering Texts and Visualizing 
#One method for clustering is Ward’s
#Ward’s method produces a hierarchy of clusterings
# Ward’s method requires  a set of pairwise distance measurements

## The following does not work 
#linkage_matrix = ward(cosdist)
#print(linkage_matrix)
#dendrogram(linkage_matrix, orientation="right", labels=names)
#plt.tight_layout()
#plt.show()

######### Alternative - this works
## Good tutorial http://brandonrose.org/clustering
linkage_matrix = ward(cosdist) #define the linkage_matrix using ward clustering pre-computed distances

fig, ax = plt.subplots(figsize=(15, 20)) # set size
ax = dendrogram(linkage_matrix, orientation="right", labels=names);

plt.tick_params(\
    axis= 'x',          # changes apply to the x-axis
    which='both',      # both major and minor ticks are affected
    bottom='off',      # ticks along the bottom edge are off
    top='off',         # ticks along the top edge are off
    labelbottom='off')

plt.tight_layout() #show plot with tight layout

#uncomment below to save figure
plt.savefig('ward_clusters.png', dpi=200) #save figure as ward_clusters

